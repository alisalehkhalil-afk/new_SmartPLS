/**
 * Authentication and Role-Based Authorization Middleware
 * Uses Cryptographic HMAC-SHA256 Signatures to prevent Token Forgery
 */
const crypto = require('crypto');
const TOKEN_SECRET = process.env.TOKEN_SECRET || 'MoF_SmartPLS_Secret_Key_2026';

function signToken(payload) {
  const data = {
    ...payload,
    iss: 'New_SmartPLS',
    ts: Date.now()
  };
  const b64 = Buffer.from(JSON.stringify(data)).toString('base64url');
  const sig = crypto.createHmac('sha256', TOKEN_SECRET).update(b64).digest('base64url');
  return `${b64}.${sig}`;
}

function parseToken(authHeader) {
  if (!authHeader) return null;
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer') return null;
  
  const token = parts[1];
  const tokenParts = token.split('.');
  if (tokenParts.length !== 2) return null;

  const [b64, sig] = tokenParts;
  if (!b64 || !sig) return null;

  // Cryptographic Signature Verification
  const expectedSig = crypto.createHmac('sha256', TOKEN_SECRET).update(b64).digest('base64url');
  if (sig !== expectedSig) {
    return null; // Forged or invalid token!
  }

  try {
    const jsonStr = Buffer.from(b64, 'base64url').toString('utf8');
    const payload = JSON.parse(jsonStr);
    if (payload && payload.iss === 'New_SmartPLS' && payload.userId && payload.role) {
      return payload;
    }
  } catch (e) {
    return null;
  }
  return null;
}

// Optional Auth: extracts user from Bearer header if present, doesn't reject if absent
function optionalAuth(req, res, next) {
  const tokenPayload = parseToken(req.headers.authorization);
  if (tokenPayload) {
    req.user = tokenPayload;
  }
  next();
}

// Require authenticated user (any valid role)
function requireAuth(req, res, next) {
  const tokenPayload = parseToken(req.headers.authorization);
  if (!tokenPayload) {
    return res.status(401).json({
      success: false,
      message: 'غير مصرح: يرجى تسجيل الدخول وإرفاق رمز الجلسة (Token)'
    });
  }
  req.user = tokenPayload;
  next();
}

// Require Admin (المستشار الإشرافي)
function requireAdmin(req, res, next) {
  const tokenPayload = parseToken(req.headers.authorization);
  if (!tokenPayload) {
    return res.status(401).json({
      success: false,
      message: 'غير مصرح: يرجى تسجيل الدخول أولاً'
    });
  }
  if (tokenPayload.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'مرفوض: هذه العملية مخصصة للمستشار الإشرافي (Admin) فقط'
    });
  }
  req.user = tokenPayload;
  next();
}

// Require any of the specified roles
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    const tokenPayload = parseToken(req.headers.authorization);
    if (!tokenPayload) {
      return res.status(401).json({
        success: false,
        message: 'غير مصرح: يرجى تسجيل الدخول أولاً'
      });
    }
    if (!allowedRoles.includes(tokenPayload.role) && tokenPayload.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: `مرفوض: صلاحيات غير كافية للوصول`
      });
    }
    req.user = tokenPayload;
    next();
  };
}

module.exports = {
  signToken,
  parseToken,
  optionalAuth,
  requireAuth,
  requireAdmin,
  requireRole
};
