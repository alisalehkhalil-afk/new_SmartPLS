// API Client and Session Manager for New_SmartPLS

const API = {
  baseUrl: '/api',

  // Current session storage
  getUser() {
    const raw = localStorage.getItem('smartpls_user');
    if (!raw) {
      return null;
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return null;
    }
  },

  setUser(user) {
    localStorage.setItem('smartpls_user', JSON.stringify(user));
  },

  logout() {
    localStorage.removeItem('smartpls_user');
    window.location.href = '/index.html';
  },

  async request(endpoint, method = 'GET', body = null) {
    const user = this.getUser();
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(user && user.token ? { 'Authorization': `Bearer ${user.token}` } : {})
      }
    };
    if (body) {
      options.body = JSON.stringify(body);
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, options);
      const data = await response.json().catch(() => ({}));
      if (!response.ok || data.error || (data.success === false && data.message)) {
        throw new Error(data.message || data.error || `خطأ في الخادم (HTTP ${response.status})`);
      }
      return data;
    } catch (err) {
      console.error(`API Error on ${endpoint}:`, err);
      throw err;
    }
  },

  // Auth
  async login(username, password, role) {
    const res = await this.request('/auth/login', 'POST', { username, password, role });
    if (res.success && res.user) {
      this.setUser(res.user);
    }
    return res;
  },

  // Systems (Level 1)
  async getSystems() {
    return this.request('/systems');
  },

  async createSystem(systemName) {
    return this.request('/systems', 'POST', { systemName });
  },

  // Surveys (Level 2)
  async getSurveys(systemId = null) {
    const query = systemId ? `?systemId=${systemId}` : '';
    return this.request(`/surveys${query}`);
  },

  async getSurveyTree(surveyId, role = null) {
    const r = role || (this.getUser() ? this.getUser().role : 'admin');
    return this.request(`/surveys/${surveyId}/tree?role=${r}`);
  },

  async createSurvey(systemId, surveyName) {
    return this.request('/surveys', 'POST', { systemId, surveyName });
  },

  // Levels & Classes (Levels 3 & 4)
  async getLevels(surveyId) {
    return this.request(`/surveys/${surveyId}/levels`);
  },

  async createLevel(surveyId, levelName) {
    return this.request(`/surveys/${surveyId}/levels`, 'POST', { levelName });
  },

  async getClasses(levelId) {
    return this.request(`/surveys/levels/${levelId}/classes`);
  },

  async createClass(levelId, className) {
    return this.request(`/surveys/levels/${levelId}/classes`, 'POST', { className });
  },

  // Questions (Level 5)
  async getQuestions(surveyId, levelId = null, classId = null, classIds = null) {
    let q = `?surveyId=${surveyId}`;
    if (levelId) q += `&levelId=${levelId}`;
    if (classId) q += `&classId=${classId}`;
    if (classIds) q += `&classIds=${Array.isArray(classIds) ? classIds.join(',') : classIds}`;
    return this.request(`/questions${q}`);
  },

  async getQuestion(id) {
    return this.request(`/questions/${id}`);
  },

  async createQuestion(questionData) {
    return this.request('/questions', 'POST', questionData);
  },

  async updateQuestion(id, questionData) {
    return this.request(`/questions/${id}`, 'PUT', questionData);
  },

  async deleteQuestion(id) {
    return this.request(`/questions/${id}`, 'DELETE');
  },

  // Evaluations
  async getEvaluations(surveyId) {
    const user = this.getUser();
    const uid = user ? user.userId : '100';
    return this.request(`/evaluations/${surveyId}?userId=${uid}`);
  },

  async submitEvaluations(answers) {
    const user = this.getUser();
    const userId = user ? user.userId : '100';
    return this.request('/evaluations/submit', 'POST', { userId, answers });
  },

  // Analytics Engine
  async getAnalytics(surveyId) {
    return this.request(`/analytics/${surveyId}`);
  },

  // Users Management
  async getUsers() {
    return this.request('/users');
  },

  async getUserGroups() {
    return this.request('/users/groups');
  },

  async createUser(userData) {
    return this.request('/users', 'POST', userData);
  },

  async updateUser(userId, userData) {
    return this.request(`/users/${userId}`, 'PUT', userData);
  },

  async deleteUser(userId) {
    return this.request(`/users/${userId}`, 'DELETE');
  },

  // Groups & Permissions Matrix Management (frmgroup_q_users)
  async getGroups() {
    return this.request('/groups');
  },

  async getGroup(id) {
    return this.request(`/groups/${id}`);
  },

  async getGroupLookupItems(type, search = '', extraParams = {}) {
    let q = `?type=${type}`;
    if (search) q += `&search=${encodeURIComponent(search)}`;
    if (extraParams.systemId) q += `&systemId=${extraParams.systemId}`;
    if (extraParams.surveyId) q += `&surveyId=${extraParams.surveyId}`;
    if (extraParams.levelId) q += `&levelId=${extraParams.levelId}`;
    return this.request(`/groups/lookup/items${q}`);
  },

  async createGroup(groupData) {
    return this.request('/groups', 'POST', groupData);
  },

  async updateGroup(id, groupData) {
    return this.request(`/groups/${id}`, 'PUT', groupData);
  },

  async deleteGroup(id) {
    return this.request(`/groups/${id}`, 'DELETE');
  },

  async cascadeAddGroup(id, systemId) {
    return this.request(`/groups/${id}/cascade-add`, 'POST', { systemId });
  },

  // Sessions & Committee Workflow
  async getSessions() {
    return this.request('/sessions');
  },

  async getSession(id) {
    return this.request(`/sessions/${id}`);
  },

  async createSession(sessionData) {
    return this.request('/sessions', 'POST', sessionData);
  },

  async submitSession(id) {
    return this.request(`/sessions/${id}/submit`, 'PUT');
  },

  async approveSession(id, approvedBy) {
    return this.request(`/sessions/${id}/approve`, 'PUT', { approvedBy });
  },

  async getSessionConsensus(id) {
    return this.request(`/sessions/${id}/consensus`);
  },

  async getSessionActionPlans(id) {
    return this.request(`/sessions/${id}/action-plans`);
  },

  // Benchmarking & Multi-System Comparison
  async getSystemBenchmark(survey1, survey2) {
    return this.request(`/analytics/compare/systems?survey1=${survey1}&survey2=${survey2}`);
  },

  // FastReport Bridge
  async getFastReportStatus() {
    return this.request('/reports/fastreport/status');
  },

  // Question Options & tst_system_q_values_list
  async getQuestionOptions(valueId) {
    return this.request(`/questions/${valueId}/options`);
  },

  async addQuestionOption(valueId, optionData) {
    return this.request(`/questions/${valueId}/options`, 'POST', optionData);
  },

  async updateQuestionOption(listId, optionData) {
    return this.request(`/questions/options/${listId}`, 'PUT', optionData);
  },

  async deleteQuestionOption(listId) {
    return this.request(`/questions/options/${listId}`, 'DELETE');
  },

  async reorderQuestionOptions(valueId, orderedIds) {
    return this.request(`/questions/${valueId}/options/reorder`, 'PUT', { orderedIds });
  },

  // WhatsApp Integration
  async getWhatsAppConfig() {
    return this.request('/whatsapp/config');
  },

  async saveWhatsAppConfig(config) {
    return this.request('/whatsapp/config', 'POST', config);
  },

  async getWhatsAppStatus() {
    return this.request('/whatsapp/status');
  },

  async getWhatsAppQr() {
    return this.request('/whatsapp/qr');
  },

  async requestWhatsAppPairingCode(phoneNumber) {
    return this.request('/whatsapp/pairing-code', 'POST', { phoneNumber });
  },

  async disconnectWhatsApp() {
    return this.request('/whatsapp/disconnect', 'POST');
  },

  async sendWhatsAppTest(data) {
    return this.request('/whatsapp/send-test', 'POST', data);
  },

  async getWhatsAppLogs(limit = 50) {
    return this.request(`/whatsapp/logs?limit=${limit}`);
  },

  async sendWhatsAppReport(data) {
    return this.request('/whatsapp/send-report', 'POST', data);
  },

  async sendSurveyWhatsAppLink(data) {
    return this.request('/whatsapp/send-survey-link', 'POST', data);
  },

  async submitPublicSurvey(data) {
    return this.request('/surveys/submit-public', 'POST', data);
  }
};

