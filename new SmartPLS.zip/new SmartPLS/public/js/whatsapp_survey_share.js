/**
 * WhatsApp Survey Sharing Component for New_SmartPLS (Google Forms Style)
 * Supports Individual Send, Group Send, Direct Copy Link, and Multi-Axis (Class) Selection.
 */

(function () {
  let modalInstance = null;
  let currentSurveyId = null;
  let currentSurveyName = '';
  let currentSystemName = '';
  let currentSurveyClasses = []; // [{ classId, className, levelName }]

  const modalHtml = `
    <div class="modal fade" id="waShareSurveyModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-lg">
          <div class="modal-header bg-success text-white py-3">
            <h5 class="modal-title fw-bold">
              <i class="fa-brands fa-whatsapp ms-2 fs-5"></i> إرسال ومشاركة رابط الاستبيان عبر الواتساب (Google Forms Style)
            </h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body p-4">
            <!-- Survey Details Banner -->
            <div class="p-3 bg-light rounded border mb-3">
              <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="badge bg-primary px-3 py-1" id="waShareSysBadge">نظام AFMIS المالي</span>
                <span class="badge bg-secondary" id="waShareSurveyIdBadge">معرف: 101</span>
              </div>
              <h6 class="fw-bold text-dark mb-0" id="waShareSurveyTitle">التقييم الشامل لكفاءة وجاهزية النظام المالي</h6>
            </div>

            <!-- Multi-Axis (Classifications) Selection Section -->
            <div class="p-3 bg-light rounded border mb-3">
              <div class="d-flex flex-wrap justify-content-between align-items-center mb-2 pb-2 border-bottom">
                <label class="form-label small fw-bold text-dark mb-0">
                  <i class="fa-solid fa-layer-group text-primary ms-1"></i> المحاور التقييمية المستهدفة (التصنيفات):
                </label>
                <div class="form-check form-switch m-0">
                  <input class="form-check-input" type="checkbox" id="waSelectAllClasses" checked onchange="window.toggleAllWaClasses(this.checked)">
                  <label class="form-check-label small fw-bold text-primary" for="waSelectAllClasses">تحديد كافة المحاور (استبيان شامل)</label>
                </div>
              </div>
              <div id="waClassesCheckboxesContainer" class="d-flex flex-wrap gap-2 pt-1">
                <span class="text-muted small"><i class="fa-solid fa-spinner fa-spin ms-1"></i> جاري استرجاع المحاور التقييمية...</span>
              </div>
              <small class="text-muted mt-2 d-block" style="font-size:0.75rem;">
                * يتم فرز وترتيب الاستبيان في هاتف المستهدف وفقاً للمحاور المختارة، مع إبراز بطاقة ترويسة مستقلة لكل محور يتبعها أسئلته.
              </small>
            </div>

            <!-- Tabs: Individual / Group / Copy Link -->
            <ul class="nav nav-pills nav-fill mb-3" id="waShareTabs" role="tablist">
              <li class="nav-item">
                <button class="nav-link active fw-bold" id="wa-tab-single-btn" data-bs-toggle="pill" data-bs-target="#wa-tab-single" type="button">
                  <i class="fa-solid fa-user-plus ms-1"></i> إرسال فردي
                </button>
              </li>
              <li class="nav-item">
                <button class="nav-link fw-bold" id="wa-tab-group-btn" data-bs-toggle="pill" data-bs-target="#wa-tab-group" type="button">
                  <i class="fa-solid fa-users ms-1"></i> إرسال جماعي لمجموعة
                </button>
              </li>
              <li class="nav-item">
                <button class="nav-link fw-bold" id="wa-tab-copy-btn" data-bs-toggle="pill" data-bs-target="#wa-tab-copy" type="button">
                  <i class="fa-solid fa-link ms-1"></i> نسخ الرابط السريع
                </button>
              </li>
            </ul>

            <div class="tab-content border rounded p-3 bg-white" id="waShareTabContent">
              <!-- TAB 1: Individual Send -->
              <div class="tab-pane fade show active" id="wa-tab-single">
                <div class="row g-3 mb-3">
                  <div class="col-md-6">
                    <label class="form-label small fw-bold">اسم المستهدف / المقيم</label>
                    <input type="text" class="form-control" id="waSingleName" placeholder="مثال: أ. محمد عبدالله - مدير الحسابات">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label small fw-bold">رقم الواتساب <span class="text-danger">*</span></label>
                    <div class="input-group">
                      <span class="input-group-text bg-light"><i class="fa-brands fa-whatsapp text-success"></i></span>
                      <input type="text" class="form-control font-monospace" id="waSinglePhone" placeholder="771110011 أو 967..." dir="ltr" required>
                    </div>
                  </div>
                </div>

                <!-- Link Mode Selector -->
                <div class="mb-3">
                  <label class="form-label small fw-bold text-dark">نوع الرابط المطلوب إرساله للمستهدف:</label>
                  <div class="d-flex gap-3">
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="waSingleLinkMode" id="linkModeDirect" value="direct" checked onchange="window.updateWaDirectLink()">
                      <label class="form-check-label small fw-bold text-success" for="linkModeDirect">
                        <i class="fa-solid fa-bolt ms-1"></i> رابط مباشر وسلس (Google Forms Style) - لا يتطلب تسجيل دخول
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="waSingleLinkMode" id="linkModeLogin" value="login" onchange="window.updateWaDirectLink()">
                      <label class="form-check-label small text-muted" for="linkModeLogin">
                        <i class="fa-solid fa-lock ms-1"></i> رابط يتطلب تسجيل الدخول بحساب المستخدم
                      </label>
                    </div>
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label small fw-bold">رسالة أو ملاحظة إضافية للمستهدف (اختياري)</label>
                  <textarea class="form-control form-control-sm" id="waSingleNote" rows="2" placeholder="أية توجيهات أو مواعيد نهائية ترغب بإرفاقها في نص الدعوة..."></textarea>
                </div>

                <div class="text-end">
                  <button type="button" class="btn btn-success px-4 fw-bold shadow-sm" id="btnSendSingleWa" onclick="window.submitWhatsAppSingleSurvey()">
                    <i class="fa-solid fa-paper-plane ms-1"></i> إرسال الدعوة والرابط عبر الواتساب
                  </button>
                </div>
              </div>

              <!-- TAB 2: Group Send -->
              <div class="tab-pane fade" id="wa-tab-group">
                <p class="text-muted small mb-3">
                  سيتم إرسال دعوة ورابط الاستبيان عبر الواتساب إلى كافة أعضاء المجموعة المسجلين بأرقام هواتف صالحة دفعة واحدة.
                </p>
                <div class="mb-3">
                  <label class="form-label small fw-bold">اختر المجموعة المستهدفة من النظام <span class="text-danger">*</span></label>
                  <select class="form-select" id="waGroupSelect" onchange="window.onWaGroupSelected()">
                    <option value="">جاري تحميل المجموعات...</option>
                  </select>
                </div>

                <div id="waGroupStats" class="p-2 mb-3 bg-light rounded border text-muted small" style="display:none;">
                  <i class="fa-solid fa-users text-primary ms-1"></i> إجمالي الأعضاء المستهدفين في المجموعة: <strong id="waGroupUserCount" class="text-dark">0</strong> عضو.
                </div>

                <div class="mb-3">
                  <label class="form-label small fw-bold">ملاحظة عامة للمجموعة (اختياري)</label>
                  <textarea class="form-control form-control-sm" id="waGroupNote" rows="2" placeholder="توجيهات عامة لكافة أعضاء المجموعة..."></textarea>
                </div>

                <div class="text-end">
                  <button type="button" class="btn btn-success px-4 fw-bold shadow-sm" id="btnSendGroupWa" onclick="window.submitWhatsAppGroupSurvey()">
                    <i class="fa-solid fa-paper-plane ms-1"></i> إرسال للجميع عبر الواتساب
                  </button>
                </div>
              </div>

              <!-- TAB 3: Copy Direct Link -->
              <div class="tab-pane fade" id="wa-tab-copy">
                <p class="text-muted small mb-2">
                  يمكنك نسخ هذا الرابط المباشر لمشاركته ونشره في مجموعات الواتساب (WhatsApp Groups) أو عبر البريد الإلكتروني:
                </p>
                <div class="input-group mb-3">
                  <input type="text" class="form-control font-monospace" id="waDirectSurveyLink" dir="ltr" readonly>
                  <button class="btn btn-primary fw-bold px-3" type="button" onclick="window.copyDirectSurveyLink()">
                    <i class="fa-solid fa-copy ms-1"></i> نسخ الرابط
                  </button>
                  <a class="btn btn-outline-secondary" id="waPreviewSurveyLink" target="_blank" href="#">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i> فتح ومعاينة
                  </a>
                </div>
                <div id="copySuccessAlert" class="alert alert-success py-2 mb-0" style="display:none;">
                  ✓ تم نسخ رابط الاستبيان إلى الحافظة بنجاح!
                </div>
              </div>
            </div>

            <!-- Result Box -->
            <div id="waShareResult" class="mt-3"></div>
          </div>
          <div class="modal-footer bg-light py-2">
            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">إغلاق</button>
          </div>
        </div>
      </div>
    </div>
  `;

  function initModalDom() {
    let modalEl = document.getElementById('waShareSurveyModal');
    if (!modalEl) {
      const div = document.createElement('div');
      div.innerHTML = modalHtml;
      modalEl = div.firstElementChild;
      document.body.appendChild(modalEl);
    }
    modalInstance = bootstrap.Modal.getOrCreateInstance(modalEl);
  }

  window.openWhatsAppSurveyShareModal = async function (surveyId, surveyName = '', systemName = '') {
    initModalDom();

    currentSurveyId = surveyId || 101;
    currentSurveyName = surveyName || 'استبيان تقييم كفاءة النظام المالي';
    currentSystemName = systemName || 'النظام المالي الحكومي';
    currentSurveyClasses = [];

    document.getElementById('waShareSurveyIdBadge').textContent = `معرف: ${currentSurveyId}`;
    document.getElementById('waShareSurveyTitle').textContent = currentSurveyName;
    document.getElementById('waShareSysBadge').textContent = currentSystemName;
    document.getElementById('waShareResult').innerHTML = '';
    document.getElementById('copySuccessAlert').style.display = 'none';

    // Reset select all checkbox
    const selectAllCb = document.getElementById('waSelectAllClasses');
    if (selectAllCb) selectAllCb.checked = true;

    // Load Classes for the survey
    await loadClassesForShare(currentSurveyId);

    // Set Direct Link
    window.updateWaDirectLink();

    // Load Groups for Group tab
    loadGroupsForShare();

    modalInstance.show();
  };

  async function loadClassesForShare(surveyId) {
    const container = document.getElementById('waClassesCheckboxesContainer');
    container.innerHTML = '<span class="text-muted small"><i class="fa-solid fa-spinner fa-spin ms-1"></i> جاري استرجاع المحاور التقييمية...</span>';

    try {
      const treeRes = await API.getSurveyTree(surveyId, 'admin');
      const tree = treeRes.tree || [];
      currentSurveyClasses = [];

      tree.forEach(lvl => {
        (lvl.classes || []).forEach(cls => {
          currentSurveyClasses.push({
            classId: cls.ClassId,
            className: cls.ClassName,
            levelName: lvl.LevelName
          });
        });
      });

      if (currentSurveyClasses.length === 0) {
        container.innerHTML = '<span class="text-muted small">لا توجد محاور مسجلة لهذا الاستبيان حتى الآن</span>';
        return;
      }

      container.innerHTML = '';
      currentSurveyClasses.forEach(c => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'form-check bg-white px-3 py-1 rounded border me-2 mb-2 d-flex align-items-center shadow-sm';
        itemDiv.innerHTML = `
          <input class="form-check-input wa-class-cb ms-2" type="checkbox" value="${c.classId}" id="waCls_${c.classId}" checked onchange="window.onWaClassCheckboxChanged()">
          <label class="form-check-label small fw-semibold text-dark cursor-pointer" for="waCls_${c.classId}">
            ${escapeHtml(c.className)} <small class="badge bg-light text-secondary border ms-1">${escapeHtml(c.levelName)}</small>
          </label>
        `;
        container.appendChild(itemDiv);
      });
    } catch (e) {
      console.error('Error loading survey classes for share:', e);
      container.innerHTML = '<span class="text-danger small">تعذر استرجاع المحاور، سيتم إرسال كافة المحاور افتراضياً</span>';
    }
  }

  window.toggleAllWaClasses = function (isChecked) {
    const checkboxes = document.querySelectorAll('.wa-class-cb');
    checkboxes.forEach(cb => { cb.checked = isChecked; });
    window.updateWaDirectLink();
  };

  window.onWaClassCheckboxChanged = function () {
    const checkboxes = Array.from(document.querySelectorAll('.wa-class-cb'));
    const allChecked = checkboxes.length > 0 && checkboxes.every(cb => cb.checked);
    const selectAllCb = document.getElementById('waSelectAllClasses');
    if (selectAllCb) selectAllCb.checked = allChecked;
    window.updateWaDirectLink();
  };

  window.getWaSelectedClasses = function () {
    const checkboxes = Array.from(document.querySelectorAll('.wa-class-cb'));
    const total = checkboxes.length;
    const checked = checkboxes.filter(cb => cb.checked);
    const isAll = (total === 0) || (checked.length === total);

    const classIds = checked.map(cb => parseInt(cb.value)).filter(Boolean);
    const classNames = currentSurveyClasses
      .filter(c => classIds.includes(c.classId))
      .map(c => c.className)
      .join('، ');

    return {
      isAll,
      classIds,
      classNames
    };
  };

  window.updateWaDirectLink = function () {
    const host = window.location.origin;
    const sel = window.getWaSelectedClasses();
    const linkMode = document.querySelector('input[name="waSingleLinkMode"]:checked')?.value || 'direct';

    let basePage = linkMode === 'login' ? 'evaluate.html' : 'survey.html';
    let url = `${host}/${basePage}?surveyId=${currentSurveyId}`;

    if (!sel.isAll && sel.classIds.length > 0) {
      url += `&classIds=${sel.classIds.join(',')}`;
    }

    const input = document.getElementById('waDirectSurveyLink');
    const preview = document.getElementById('waPreviewSurveyLink');
    if (input) input.value = url;
    if (preview) preview.href = url;
  };

  async function loadGroupsForShare() {
    const sel = document.getElementById('waGroupSelect');
    try {
      const res = await API.request('/groups');
      sel.innerHTML = '<option value="">-- اختر المجموعة المستهدفة --</option>';
      (res.groups || []).forEach(g => {
        const opt = document.createElement('option');
        opt.value = g.groupId;
        opt.textContent = `${g.groupNameAr || ('مجموعة ' + g.groupId)} (${g.usersCount || 0} مستخدم)`;
        opt.dataset.usersCount = g.usersCount || 0;
        sel.appendChild(opt);
      });
    } catch (e) {
      sel.innerHTML = '<option value="">تعذر جلب المجموعات</option>';
    }
  }

  window.onWaGroupSelected = function () {
    const sel = document.getElementById('waGroupSelect');
    const opt = sel.options[sel.selectedIndex];
    const stats = document.getElementById('waGroupStats');
    if (sel.value && opt) {
      stats.style.display = 'block';
      document.getElementById('waGroupUserCount').textContent = opt.dataset.usersCount || 0;
    } else {
      stats.style.display = 'none';
    }
  };

  function fallbackCopyText(inputEl) {
    try {
      inputEl.focus();
      inputEl.select();
      document.execCommand('copy');
    } catch (e) {
      console.warn('Fallback copy failed', e);
    }
  }

  window.copyDirectSurveyLink = function () {
    window.updateWaDirectLink();
    const linkInput = document.getElementById('waDirectSurveyLink');
    linkInput.select();
    linkInput.setSelectionRange(0, 99999);

    const textToCopy = linkInput.value;
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(textToCopy).catch(() => {
        fallbackCopyText(linkInput);
      });
    } else {
      fallbackCopyText(linkInput);
    }

    const alertBox = document.getElementById('copySuccessAlert');
    alertBox.style.display = 'block';
    setTimeout(() => { alertBox.style.display = 'none'; }, 2500);
  };

  window.submitWhatsAppSingleSurvey = async function () {
    const name = document.getElementById('waSingleName').value.trim();
    const phone = document.getElementById('waSinglePhone').value.trim();
    const note = document.getElementById('waSingleNote').value.trim();
    const linkMode = document.querySelector('input[name="waSingleLinkMode"]:checked')?.value || 'direct';
    const btn = document.getElementById('btnSendSingleWa');
    const resultBox = document.getElementById('waShareResult');
    const selClasses = window.getWaSelectedClasses();

    if (!phone) {
      alert('يرجى إدخال رقم الواتساب للمستهدف أولاً');
      document.getElementById('waSinglePhone').focus();
      return;
    }

    if (!selClasses.isAll && selClasses.classIds.length === 0) {
      alert('يرجى تحديد محور تقييمي واحد على الأقل أو تفعيل "تحديد كافة المحاور".');
      return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin ms-1"></i> جاري الإرسال عبر البوابة...';
    resultBox.innerHTML = '<div class="alert alert-info py-2">جاري إرسال دعوة ورابط الاستبيان عبر الواتساب...</div>';

    try {
      const res = await API.sendSurveyWhatsAppLink({
        surveyId: currentSurveyId,
        classIds: selClasses.isAll ? null : selClasses.classIds,
        classNames: selClasses.isAll ? null : selClasses.classNames,
        type: 'individual',
        recipientName: name,
        recipientPhone: phone,
        linkMode: linkMode,
        customNote: note
      });

      if (res.success) {
        resultBox.innerHTML = `
          <div class="alert alert-success py-3">
            <div class="fw-bold"><i class="fa-solid fa-circle-check ms-1"></i> ${res.message || 'تم إرسال رابط الاستبيان بنجاح!'}</div>
            <div class="small text-muted mt-1 font-monospace" dir="ltr">${res.surveyUrl}</div>
          </div>
        `;
      } else {
        resultBox.innerHTML = `<div class="alert alert-danger py-2">فشل الإرسال: ${res.message || 'تعذر التواصل مع بوابة الواتساب'}</div>`;
      }
    } catch (e) {
      resultBox.innerHTML = `<div class="alert alert-danger py-2">خطأ: ${e.message}</div>`;
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="fa-solid fa-paper-plane ms-1"></i> إرسال الدعوة والرابط عبر الواتساب';
    }
  };

  window.submitWhatsAppGroupSurvey = async function () {
    const groupId = document.getElementById('waGroupSelect').value;
    const note = document.getElementById('waGroupNote').value.trim();
    const btn = document.getElementById('btnSendGroupWa');
    const resultBox = document.getElementById('waShareResult');
    const selClasses = window.getWaSelectedClasses();

    if (!groupId) {
      alert('يرجى اختيار المجموعة المستهدفة أولاً');
      return;
    }

    if (!selClasses.isAll && selClasses.classIds.length === 0) {
      alert('يرجى تحديد محور تقييمي واحد على الأقل أو تفعيل "تحديد كافة المحاور".');
      return;
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin ms-1"></i> جاري الإرسال للمجموعة...';
    resultBox.innerHTML = '<div class="alert alert-info py-2">جاري إرسال روابط الاستبيان لكافة أعضاء المجموعة عبر الواتساب...</div>';

    try {
      const res = await API.sendSurveyWhatsAppLink({
        surveyId: currentSurveyId,
        classIds: selClasses.isAll ? null : selClasses.classIds,
        classNames: selClasses.isAll ? null : selClasses.classNames,
        type: 'group',
        groupId: groupId,
        linkMode: 'direct',
        customNote: note
      });

      if (res.success) {
        resultBox.innerHTML = `
          <div class="alert alert-success py-3">
            <div class="fw-bold"><i class="fa-solid fa-circle-check ms-1"></i> ${res.message}</div>
            <div class="small text-muted mt-1">تم إرسال (${res.sentCount}) دعوة بنجاح.</div>
          </div>
        `;
      } else {
        resultBox.innerHTML = `<div class="alert alert-danger py-2">فشل الإرسال: ${res.message}</div>`;
      }
    } catch (e) {
      resultBox.innerHTML = `<div class="alert alert-danger py-2">خطأ: ${e.message}</div>`;
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="fa-solid fa-paper-plane ms-1"></i> إرسال للجميع عبر الواتساب';
    }
  };

  function escapeHtml(text) {
    if (!text) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
})();
