// Chart.js helper module for New_SmartPLS Analytics

const SmartCharts = {
  radarChartInstance: null,
  doughnutChartInstance: null,
  barChartInstance: null,

  renderRadarChart(canvasId, radarData) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.radarChartInstance) {
      this.radarChartInstance.destroy();
      this.radarChartInstance = null;
    }

    if (!radarData || !radarData.labels || radarData.labels.length === 0) {
      return;
    }

    const labels = radarData.labels || [];
    const earnedData = radarData.datasets && radarData.datasets[0] ? radarData.datasets[0].data : [];
    const benchData = radarData.datasets && radarData.datasets[1] ? radarData.datasets[1].data : [];

    this.radarChartInstance = new Chart(ctx, {
      type: 'radar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'مستوى الأداء والجاهزية الفعلي %',
            data: earnedData,
            backgroundColor: 'rgba(30, 55, 153, 0.25)',
            borderColor: '#1e3799',
            borderWidth: 2,
            pointBackgroundColor: '#1e3799',
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: '#1e3799',
            pointRadius: 4
          },
          {
            label: 'المعيار الحكومي المعتمد %',
            data: benchData,
            backgroundColor: 'rgba(0, 148, 50, 0.1)',
            borderColor: '#009432',
            borderWidth: 2,
            borderDash: [5, 5],
            pointBackgroundColor: '#009432',
            pointRadius: 3
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              font: { family: 'Segoe UI, Tahoma', size: 12 }
            }
          },
          tooltip: {
            callbacks: {
              label: (context) => `${context.dataset.label}: ${context.raw}%`
            }
          }
        },
        scales: {
          r: {
            angleLines: { color: '#e2e8f0' },
            grid: { color: '#e2e8f0' },
            pointLabels: {
              font: { family: 'Segoe UI, Tahoma', size: 12, weight: 'bold' },
              color: '#0a3d62'
            },
            suggestedMin: 0,
            suggestedMax: 100,
            ticks: {
              stepSize: 20,
              callback: (val) => `${val}%`
            }
          }
        }
      }
    });
  },

  renderDefectsDoughnut(canvasId, defectBreakdown) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.doughnutChartInstance) {
      this.doughnutChartInstance.destroy();
      this.doughnutChartInstance = null;
    }

    if (!defectBreakdown || !Array.isArray(defectBreakdown) || defectBreakdown.length === 0) {
      return;
    }

    const labels = defectBreakdown.map(d => d.name);
    const data = defectBreakdown.map(d => d.defectSharePct);
    const colorMap = {
      'إداري': '#3498db',
      'فني': '#e67e22',
      'برمجي': '#e74c3c',
      'سوء استخدام': '#9b59b6'
    };
    const colors = defectBreakdown.map(d => colorMap[d.key] || '#6c757d');

    this.doughnutChartInstance = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: labels,
        datasets: [{
          data: data,
          backgroundColor: colors,
          borderWidth: 2,
          borderColor: '#ffffff'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: { family: 'Segoe UI, Tahoma', size: 11 }
            }
          },
          tooltip: {
            callbacks: {
              label: (context) => `نسبة المساهمة في الخلل: ${context.raw}%`
            }
          }
        },
        cutout: '65%'
      }
    });
  },

  renderCategoryBars(canvasId, axesList) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.barChartInstance) {
      this.barChartInstance.destroy();
      this.barChartInstance = null;
    }

    if (!axesList || !Array.isArray(axesList) || axesList.length === 0) {
      return;
    }

    const labels = axesList.map(a => a.axisName || a.axis || 'محور');
    const data = axesList.map(a => a.scorePct || 0);
    const bgColors = data.map(val => val >= 80 ? '#009432' : (val >= 60 ? '#f39c12' : '#e74c3c'));

    this.barChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'نسبة الإنجاز والجاهزية %',
          data: data,
          backgroundColor: bgColors,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: {
            min: 0,
            max: 100,
            ticks: {
              callback: (val) => `${val}%`
            }
          }
        }
      }
    });
  }
};
